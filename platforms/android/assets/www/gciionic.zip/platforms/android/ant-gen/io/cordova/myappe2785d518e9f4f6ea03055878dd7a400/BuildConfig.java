/** Automatically generated file. DO NOT MODIFY */
package io.cordova.myappe2785d518e9f4f6ea03055878dd7a400;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}